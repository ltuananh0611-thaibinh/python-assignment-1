length = float(input("Enter the length: "))
width = float(input("Enter the width: "))

perimeter = 2 * (length + width)
area = length * width

print("Perimeter:", perimeter)
print("Area:", area)
