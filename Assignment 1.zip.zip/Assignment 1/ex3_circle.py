import math

radius = float(input("Enter the radius of the circle: "))
circumference = 2 * math.pi * radius

print("The circumference is:", circumference)
