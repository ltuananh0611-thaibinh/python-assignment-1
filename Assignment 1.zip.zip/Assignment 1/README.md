# Assignment 1 – Python Basics

## Description
This assignment contains basic Python exercises to practice variables,
input/output, calculations, and random number generation.

## Files Included

- ex2_greeting.py  
  Prints a greeting message to the user.

- ex3_circle.py  
  Calculates the area and circumference of a circle.

- ex4_rectangle.py  
  Calculates the area and perimeter of a rectangle.

- ex5_number.py  
  Performs basic number operations and comparisons.

- ex6_medieval_units.py  
  Converts medieval units into modern units.

- ex7_random_codes.py  
  Generates random 3-digit and 4-digit codes.

## How to Run
Open each file and run it using Python 3.

## Author
Le Tuan Anh

