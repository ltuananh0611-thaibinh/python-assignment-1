name = input("Enter your name: ")
print(f"Hello, {name}!")


