a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))

sum_numbers = a + b + c
product = a * b * c
average = sum_numbers / 3

print("Sum:", sum_numbers)
print("Product:", product)
print("Average:", average)
