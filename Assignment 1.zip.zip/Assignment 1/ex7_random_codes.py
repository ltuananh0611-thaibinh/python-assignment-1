import random

# 3-digit code (0–9)
code1 = (
    random.randint(0, 9),
    random.randint(0, 9),
    random.randint(0, 9)
)

# 4-digit code (1–6)
code2 = (
    random.randint(1, 6),
    random.randint(1, 6),
    random.randint(1, 6),
    random.randint(1, 6)
)

print("3-digit code:", code1)
print("4-digit code:", code2)


